"use client"

import { type FormEvent, useRef } from "react"

export default function Home() {
  const formRef = useRef<HTMLFormElement>(null)
  const statusRef = useRef<HTMLDivElement>(null)
  const submitBtnRef = useRef<HTMLButtonElement>(null)
  const btnTextRef = useRef<HTMLSpanElement>(null)
  const btnSpinnerRef = useRef<HTMLSpanElement>(null)

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!formRef.current || !statusRef.current) return

    const statusEl = statusRef.current
    statusEl.textContent = ""
    statusEl.className = "status"

    const formData = new FormData(formRef.current)
    const name = (formData.get("name") as string)?.trim() || ""
    const email = (formData.get("email") as string)?.trim() || ""
    const message = (formData.get("message") as string)?.trim() || ""

    if (!message) {
      statusEl.textContent = "Введите сообщение."
      statusEl.classList.add("status--error")
      return
    }

    try {
      if (submitBtnRef.current) submitBtnRef.current.disabled = true
      if (btnTextRef.current) btnTextRef.current.textContent = "Отправка..."
      if (btnSpinnerRef.current) btnSpinnerRef.current.style.display = "inline-block"

      const response = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, message }),
      })

      const data = await response.json()

      if (response.ok && data.ok) {
        statusEl.textContent = "✅ Сообщение отправлено! Спасибо."
        statusEl.classList.add("status--ok")
        formRef.current.reset()
      } else {
        throw new Error(data.error || "Ошибка отправки")
      }
    } catch (err) {
      console.error(err)
      statusEl.textContent = "❌ Не удалось отправить. Попробуйте позже."
      statusEl.classList.add("status--error")
    } finally {
      if (submitBtnRef.current) submitBtnRef.current.disabled = false
      if (btnTextRef.current) btnTextRef.current.textContent = "Отправить"
      if (btnSpinnerRef.current) btnSpinnerRef.current.style.display = "none"
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "radial-gradient(circle at top left, #ffedd5, #fff7ed)",
      }}
    >
      <div
        style={{
          background: "#ffffff",
          padding: "26px 28px",
          borderRadius: "20px",
          maxWidth: "430px",
          width: "100%",
          boxShadow: "0 18px 45px rgba(0, 0, 0, 0.12)",
          border: "1px solid rgba(249, 115, 22, 0.18)",
        }}
      >
        <div
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "6px",
            padding: "4px 10px",
            borderRadius: "999px",
            background: "rgba(251, 146, 60, 0.12)",
            color: "#c2410c",
            fontSize: "12px",
            fontWeight: "600",
            marginBottom: "10px",
          }}
        >
          <span
            style={{
              width: "7px",
              height: "7px",
              borderRadius: "999px",
              background: "#fb923c",
            }}
          ></span>
          Оранжевая форма связи
        </div>

        <h1 style={{ fontSize: "1.45rem", margin: "0 0 4px", color: "#7c2d12" }}>Напишите нам</h1>
        <p style={{ fontSize: "0.9rem", color: "#9a3412", marginBottom: "20px" }}>
          Оставьте свои контакты и сообщение — мы ответим в ближайшее время.
        </p>

        <form ref={formRef} onSubmit={handleSubmit}>
          <div style={{ display: "flex", gap: "10px" }}>
            <div style={{ flex: 1, marginBottom: "14px" }}>
              <label
                htmlFor="name"
                style={{
                  display: "block",
                  fontSize: "0.85rem",
                  marginBottom: "4px",
                  color: "#7c2d12",
                  fontWeight: "500",
                }}
              >
                Имя
              </label>
              <input
                type="text"
                id="name"
                name="name"
                placeholder="Как к вам обращаться?"
                style={{
                  width: "100%",
                  padding: "9px 11px",
                  borderRadius: "12px",
                  border: "1px solid #fed7aa",
                  fontSize: "0.95rem",
                  outline: "none",
                  background: "#fff7ed",
                  transition: "all 0.15s",
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = "#fb923c"
                  e.currentTarget.style.boxShadow = "0 0 0 1px rgba(251, 146, 60, 0.6)"
                  e.currentTarget.style.background = "#ffffff"
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = "#fed7aa"
                  e.currentTarget.style.boxShadow = "none"
                  e.currentTarget.style.background = "#fff7ed"
                }}
              />
            </div>
            <div style={{ flex: 1, marginBottom: "14px" }}>
              <label
                htmlFor="email"
                style={{
                  display: "block",
                  fontSize: "0.85rem",
                  marginBottom: "4px",
                  color: "#7c2d12",
                  fontWeight: "500",
                }}
              >
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                placeholder="you@example.com"
                style={{
                  width: "100%",
                  padding: "9px 11px",
                  borderRadius: "12px",
                  border: "1px solid #fed7aa",
                  fontSize: "0.95rem",
                  outline: "none",
                  background: "#fff7ed",
                  transition: "all 0.15s",
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = "#fb923c"
                  e.currentTarget.style.boxShadow = "0 0 0 1px rgba(251, 146, 60, 0.6)"
                  e.currentTarget.style.background = "#ffffff"
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = "#fed7aa"
                  e.currentTarget.style.boxShadow = "none"
                  e.currentTarget.style.background = "#fff7ed"
                }}
              />
            </div>
          </div>

          <div style={{ marginBottom: "14px" }}>
            <label
              htmlFor="message"
              style={{
                display: "block",
                fontSize: "0.85rem",
                marginBottom: "4px",
                color: "#7c2d12",
                fontWeight: "500",
              }}
            >
              Сообщение *
            </label>
            <textarea
              id="message"
              name="message"
              required
              placeholder="Расскажите, что вам нужно..."
              style={{
                width: "100%",
                padding: "9px 11px",
                borderRadius: "12px",
                border: "1px solid #fed7aa",
                fontSize: "0.95rem",
                outline: "none",
                background: "#fff7ed",
                transition: "all 0.15s",
                resize: "vertical",
                minHeight: "90px",
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "#fb923c"
                e.currentTarget.style.boxShadow = "0 0 0 1px rgba(251, 146, 60, 0.6)"
                e.currentTarget.style.background = "#ffffff"
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = "#fed7aa"
                e.currentTarget.style.boxShadow = "none"
                e.currentTarget.style.background = "#fff7ed"
              }}
            ></textarea>
          </div>

          <button
            type="submit"
            ref={submitBtnRef}
            style={{
              width: "100%",
              padding: "10px 16px",
              borderRadius: "999px",
              border: "none",
              fontSize: "0.95rem",
              fontWeight: "600",
              cursor: "pointer",
              background: "linear-gradient(135deg, #ea580c, #f97316)",
              color: "#ffffff",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "8px",
              transition: "transform 0.08s ease, box-shadow 0.08s ease, opacity 0.08s ease",
            }}
            onMouseEnter={(e) => {
              if (!e.currentTarget.disabled) {
                e.currentTarget.style.transform = "translateY(-1px)"
                e.currentTarget.style.boxShadow = "0 10px 25px rgba(248, 113, 22, 0.4)"
              }
            }}
            onMouseLeave={(e) => {
              if (!e.currentTarget.disabled) {
                e.currentTarget.style.transform = "translateY(0)"
                e.currentTarget.style.boxShadow = "none"
              }
            }}
          >
            <span ref={btnTextRef}>Отправить</span>
            <span ref={btnSpinnerRef} style={{ display: "none" }}>
              ⏳
            </span>
          </button>

          <div
            ref={statusRef}
            style={{
              marginTop: "10px",
              fontSize: "0.9rem",
              minHeight: "1.1em",
              color: "transparent",
            }}
          ></div>
        </form>
      </div>
    </div>
  )
}
