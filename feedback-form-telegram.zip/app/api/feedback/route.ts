export async function POST(request: Request) {
  try {
    const { name, email, message } = await request.json()

    if (!message || !message.trim()) {
      return Response.json({ ok: false, error: "Пустое сообщение" }, { status: 400 })
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN
    const chatId = process.env.TELEGRAM_CHAT_ID

    if (!botToken || !chatId) {
      console.error("TELEGRAM_BOT_TOKEN или TELEGRAM_CHAT_ID не заданы")
      return Response.json({ ok: false, error: "Не заданы TELEGRAM_BOT_TOKEN или TELEGRAM_CHAT_ID" }, { status: 500 })
    }

    const text =
      "🧡 Новая заявка с сайта\n\n" +
      (name ? `👤 Имя: ${name}\n` : "") +
      (email ? `📧 Email: ${email}\n` : "") +
      `💬 Сообщение:\n${message}`

    const url = `https://api.telegram.org/bot${botToken}/sendMessage`

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
      }),
    })

    const data = await response.json()

    if (!response.ok) {
      console.error("Ошибка Telegram API:", data)
      return Response.json({ ok: false, error: data.description || "Ошибка при отправке в Telegram" }, { status: 500 })
    }

    return Response.json({ ok: true })
  } catch (err) {
    console.error("Ошибка обработки запроса:", err)
    return Response.json({ ok: false, error: "Ошибка сервера" }, { status: 500 })
  }
}
